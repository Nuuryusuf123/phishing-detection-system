HYBRID WEB APP DATASET PACKAGE
==============================

This package is ready for building your Streamlit web app.

Folders
-------
1. SMS/
   - sms_dataset_ready_10k.csv
   - sms_train.csv
   - sms_val.csv
   - sms_test.csv

2. URL/
   - url_dataset_ready_10k.csv
   - url_train.csv
   - url_val.csv
   - url_test.csv

Dataset counts
--------------
SMS dataset total: 10,000 rows
- legitimate (0): 5,000
- phishing (1): 5,000

URL dataset total: 10,000 rows
- legitimate (0): 5,000
- phishing (1): 5,000

Split ratio
-----------
- Train: 70%
- Validation: 15%
- Test: 15%

How to train your models
------------------------
1. SMS (BERT or baseline text model)
   - Use SMS/sms_train.csv for training
   - Use SMS/sms_val.csv for validation
   - Use SMS/sms_test.csv for final testing
   - Input columns: text, label

2. URL (XGBoost)
   - Use URL/url_train.csv for training
   - Use URL/url_val.csv for validation
   - Use URL/url_test.csv for final testing
   - All columns except 'label' are features
   - Target column: label

Recommended workflow
--------------------
SMS model:
text -> preprocessing/tokenizer -> BERT -> probability

URL model:
URL features -> XGBoost -> probability

Hybrid decision:
final_score = (sms_score + url_score) / 2
if final_score >= 0.5 -> phishing
else -> safe

Label meaning
-------------
0 = legitimate / safe
1 = phishing / malicious