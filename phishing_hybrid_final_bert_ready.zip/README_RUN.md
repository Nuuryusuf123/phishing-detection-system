# Final Graduate-Level Web App (BERT + XGBoost + Streamlit)

## What this package is
A login-first real cybersecurity web app with:

- real login page
- BERT SMS model integration
- XGBoost URL model integration
- training scripts
- testing/evaluation script
- system overview
- dashboard
- hybrid detection
- charts
- explainability
- history
- CSV/PDF reports
- admin analytics
- cyber-style UI

## Where to train and test the models
Train both models in **VS Code terminal** inside this project folder.

### 1) BERT SMS training
```bash
python scripts/train_bert_sms.py
```

### 2) URL XGBoost training
```bash
python scripts/train_xgboost_url.py
```

### 3) Evaluate both models
```bash
python scripts/evaluate_models.py
```

## Where the trained models are saved
- BERT -> `models/bert_sms_model/`
- XGBoost -> `models/url/xgboost_url_model.joblib`

## How to run the real web app
```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Login
- admin / admin123
- student / student123

## Important
The web app starts from the **login page only**.
After login, all pages and system functions become available.
